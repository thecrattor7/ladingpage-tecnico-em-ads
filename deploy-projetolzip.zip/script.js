// =================== CAROUSEL ===================
(function(){
  const slides = document.getElementById('slidesInner');
  const total = slides.children.length;
  let idx = 0;

  function update(){ slides.style.transform = `translateX(-${idx*100}%)`; }

  document.getElementById('nextSlide').onclick = ()=>{
    idx = (idx+1) % total;
    update();
  }
  document.getElementById('prevSlide').onclick = ()=>{
    idx = (idx-1+total) % total;
    update();
  }

  // auto rotate
  setInterval(()=>{
    idx = (idx+1) % total;
    update();
  }, 6000);
})();

// =================== SCROLL ===================
function scrollToSection(id){
  document.getElementById(id)?.scrollIntoView({behavior:'smooth',block:'start'});
}

// =================== PYTHON RUNNER ===================
function outf(text){
  const out = document.getElementById('output');
  out.textContent += text;
}
function builtinRead(x){
  if (Sk.builtinFiles === undefined || Sk.builtinFiles['files'][x] === undefined){
    throw "File not found: '"+x+"'";
  }
  return Sk.builtinFiles['files'][x];
}
function runCode(){
  const prog = document.getElementById('code').value;
  const out = document.getElementById('output');
  out.textContent = '';
  Sk.configure({ output:outf, read:builtinRead });
  const myPromise = Sk.misceval.asyncToPromise(function(){
    return Sk.importMainWithBody('<stdin>', false, prog, true);
  });
  myPromise.then(
    ()=> console.log('ok'),
    (err)=> out.textContent = err.toString()
  );
  
}
document.getElementById('runBtn').addEventListener('click', runCode);
document.getElementById('exBtn').addEventListener('click', ()=>{
  document.getElementById('code').value = "# Contador de notas\nfor i in range(1,6):\n    print('Nota', i)";
});
document.getElementById('clearBtn').addEventListener('click', ()=>{
  document.getElementById('output').textContent = '';
});

// =================== QUIZ ===================
function checkQuiz(btn, status){
  const result = document.getElementById('quizResult');
  if(status === 'correto'){
    result.textContent = "✅ Acertou! CSS é usado para estilizar os sites.";
    result.style.color = "lightgreen";
  } else {
    result.textContent = "❌ Ops, tente de novo!";
    result.style.color = "tomato";
  }
}


// =================== MINI JOGO ===================
const canvas = document.getElementById("gameCanvas");
const startBtn = document.getElementById("startGameBtn");
let gameStarted = false;

if(canvas && startBtn){
  const ctx = canvas.getContext("2d");

  let player, obstacle, gravity, gameOver, animationId, obstacleSpeed;

  function resetGame(){
    player = { x: 50, y: 120, w: 30, h: 50, vy: 0, jumping: false };
    obstacle = { x: 600, y: 130, w: 20, h: 40 };
    gravity = 1.5;
    gameOver = false;
    obstacleSpeed = 3; // velocidade reduzida
  }

  function drawStickman(x, y){
    // Cabeça
    ctx.beginPath();
    ctx.arc(x+15, y+10, 10, 0, Math.PI*2);
    ctx.fillStyle = "#222";
    ctx.fill();
    // Corpo
    ctx.beginPath();
    ctx.moveTo(x+15, y+20);
    ctx.lineTo(x+15, y+40);
    ctx.strokeStyle = "#222";
    ctx.lineWidth = 3;
    ctx.stroke();
    // Braço esquerdo
    ctx.beginPath();
    ctx.moveTo(x+15, y+25);
    ctx.lineTo(x+5, y+35);
    ctx.stroke();
    // Braço direito
    ctx.beginPath();
    ctx.moveTo(x+15, y+25);
    ctx.lineTo(x+25, y+35);
    ctx.stroke();
    // Perna esquerda
    ctx.beginPath();
    ctx.moveTo(x+15, y+40);
    ctx.lineTo(x+7, y+50);
    ctx.stroke();
    // Perna direita
    ctx.beginPath();
    ctx.moveTo(x+15, y+40);
    ctx.lineTo(x+23, y+50);
    ctx.stroke();
  }

  function draw(){
    ctx.clearRect(0,0,canvas.width,canvas.height);

    // Player (stickman)
    drawStickman(player.x, player.y);

    // Obstacle
    ctx.fillStyle = "red";
    ctx.fillRect(obstacle.x, obstacle.y, obstacle.w, obstacle.h);
  }

  function update(){
    if(gameOver) return;

    // Physics
    player.y += player.vy;
    if(player.y + player.h < canvas.height){
      player.vy += gravity;
    } else {
      player.vy = 0;
      player.y = canvas.height - player.h;
      player.jumping = false;
    }

    // Move obstacle (velocidade reduzida)
    obstacle.x -= obstacleSpeed;
    if(obstacle.x < -20){
      obstacle.x = 600;
    }

    // Collision
    if(player.x < obstacle.x + obstacle.w &&
       player.x + player.w > obstacle.x &&
       player.y < obstacle.y + obstacle.h &&
       player.y + player.h > obstacle.y){
      gameOver = true;
      cancelAnimationFrame(animationId);
      alert("💀 Game Over! Clique em 'Iniciar' para jogar novamente.");
    }
  }

  function loop(){
    update();
    draw();
    if(!gameOver) animationId = requestAnimationFrame(loop);
  }

  startBtn.onclick = function(){
    resetGame();
    gameStarted = true;
    loop();
  };

  document.addEventListener("keydown", e=>{
    if(gameStarted && e.code === "Space" && !player.jumping && !gameOver){
      player.vy = -18; // pulo ajustado para o novo tamanho
      player.jumping = true;
    }
  });

  // Desenha o estado inicial
  resetGame();
  draw();
}
